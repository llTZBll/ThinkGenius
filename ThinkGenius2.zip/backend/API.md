# 后端 API 文档

## 基础信息
- 基础URL: `http://localhost:8080`
- 所有请求和响应均使用 JSON 格式
- 认证方式：待定

## API 端点

### 1. 图片上传
- **URL**: `/api/upload`
- **方法**: POST
- **描述**: 上传图片文件
- **请求参数**:
  - `file`: 图片文件（multipart/form-data）
- **响应**:
  ```json
  {
    "success": true,
    "message": "上传成功",
    "data": {
      "url": "图片访问地址"
    }
  }
  ```

### 2. 获取图片列表
- **URL**: `/api/images`
- **方法**: GET
- **描述**: 获取所有已上传的图片列表
- **请求参数**: 无
- **响应**:
  ```json
  {
    "success": true,
    "data": [
      {
        "id": "图片ID",
        "url": "图片访问地址",
        "uploadTime": "上传时间"
      }
    ]
  }
  ```

### 3. 删除图片
- **URL**: `/api/images/{id}`
- **方法**: DELETE
- **描述**: 删除指定ID的图片
- **请求参数**:
  - `id`: 图片ID（路径参数）
- **响应**:
  ```json
  {
    "success": true,
    "message": "删除成功"
  }
  ```

## 错误响应
所有API在发生错误时都会返回以下格式：
```json
{
  "success": false,
  "message": "错误信息",
  "errorCode": "错误代码"
}
```

## 状态码
- 200: 请求成功
- 400: 请求参数错误
- 401: 未授权
- 403: 禁止访问
- 404: 资源不存在
- 500: 服务器内部错误 