package com.photo.controller;

import com.photo.entity.User;
import com.photo.service.UserService;
import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin
public class AuthController {

    @Autowired
    private UserService userService;

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest loginRequest) {
        try {
            String token = userService.login(loginRequest.getUsername(), loginRequest.getPassword());
            return ResponseEntity.ok(new AuthResponse(token));
        } catch (RuntimeException e) {
            Map<String, String> response = new HashMap<>();
            response.put("message", e.getMessage());
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(response);
        }
    }

    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody RegisterRequest registerRequest) {
        try {
            // 验证请求数据
            if (registerRequest.getUsername() == null || registerRequest.getUsername().trim().isEmpty()) {
                return createErrorResponse("用户名不能为空", HttpStatus.BAD_REQUEST);
            }
            if (registerRequest.getEmail() == null || registerRequest.getEmail().trim().isEmpty()) {
                return createErrorResponse("邮箱不能为空", HttpStatus.BAD_REQUEST);
            }
            if (registerRequest.getPassword() == null || registerRequest.getPassword().trim().isEmpty()) {
                return createErrorResponse("密码不能为空", HttpStatus.BAD_REQUEST);
            }
            if (registerRequest.getPassword().length() < 6) {
                return createErrorResponse("密码长度不能小于6位", HttpStatus.BAD_REQUEST);
            }

            User user = new User();
            user.setUsername(registerRequest.getUsername().trim());
            user.setEmail(registerRequest.getEmail().trim());
            user.setPassword(registerRequest.getPassword());
            
            userService.register(user);
            return ResponseEntity.ok().build();
            
        } catch (RuntimeException e) {
            if (e.getMessage().contains("用户名已存在") || e.getMessage().contains("邮箱已被使用")) {
                return createErrorResponse(e.getMessage(), HttpStatus.CONFLICT);
            }
            return createErrorResponse(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    private ResponseEntity<?> createErrorResponse(String message, HttpStatus status) {
        Map<String, String> response = new HashMap<>();
        response.put("message", message);
        return ResponseEntity.status(status).body(response);
    }

    @Data
    static class LoginRequest {
        private String username;
        private String password;
    }

    @Data
    static class RegisterRequest {
        private String username;
        private String email;
        private String password;
    }

    @Data
    static class AuthResponse {
        private String token;
        private String username;
        
        public AuthResponse(String token) {
            this.token = token;
        }
    }
} 