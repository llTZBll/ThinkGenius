package com.photo.controller;

import com.photo.entity.Keyword;
import com.photo.service.KeywordService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.HashMap;

@RestController
@RequestMapping("/api/keywords")
@CrossOrigin
public class KeywordController {

    @Autowired
    private KeywordService keywordService;

    @PostMapping("/generate")
    public ResponseEntity<?> generateKeywords(@RequestParam String prompt) {
        try {
            Keyword keyword = keywordService.generateKeywords(prompt);
            return ResponseEntity.ok(keyword);
        } catch (Exception e) {
            e.printStackTrace();
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.internalServerError().body(error);
        }
    }

    @GetMapping
    public ResponseEntity<List<Keyword>> getHistory() {
        return ResponseEntity.ok(keywordService.list());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Keyword> getById(@PathVariable Long id) {
        return ResponseEntity.ok(keywordService.getById(id));
    }
} 