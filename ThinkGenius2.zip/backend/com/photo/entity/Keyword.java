package com.photo.entity;

import lombok.Data;
import java.util.List;

@Data
public class Keyword {
    private Long id;
    private String prompt;
    private String title;
    private List<String> keywords;
    private String type;
} 