package com.photo.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.photo.entity.Keyword;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface KeywordMapper extends BaseMapper<Keyword> {
} 