package com.photo.service;

import java.util.List;

public interface BaiduApiService {
    List<String> generateKeywords(String prompt);
} 