package com.photo.service;

import com.photo.entity.Keyword;
import java.util.List;

public interface KeywordService {
    Keyword generateKeywords(String prompt);
    List<Keyword> list();
    Keyword getById(Long id);
    void save(Keyword keyword);
} 