package com.photo.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.photo.entity.User;

public interface UserService extends IService<User> {
    String login(String username, String password);
    void register(User user);
    User getCurrentUser();
} 