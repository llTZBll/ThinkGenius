package com.photo.service.impl;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.photo.config.BaiduApiConfig;
import com.photo.service.BaiduApiService;
import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Service
public class BaiduApiServiceImpl implements BaiduApiService {

    @Autowired
    private BaiduApiConfig baiduApiConfig;

    private final ObjectMapper objectMapper = new ObjectMapper();

    @Override
    public List<String> generateKeywords(String prompt) {
        try {
            String requestBody = String.format(
                "{" +
                "    \"model\": \"ernie-4.0-8k\"," +
                "    \"messages\": [" +
                "        {" +
                "            \"role\": \"user\"," +
                "            \"content\": \"你是一个关键词生成助手。请根据用户输入的主题，生成3-5个相关的关键词或短语。每个关键词应该简短精炼，并且与主题高度相关。请直接返回关键词列表，每行一个关键词，不要添加序号或其他标记。\\n\\n主题：%s\"" +
                "        }" +
                "    ]," +
                "    \"temperature\": 0.7," +
                "    \"top_p\": 0.9," +
                "    \"stream\": false" +
                "}", prompt);

            HttpPost httpPost = new HttpPost(baiduApiConfig.getApiUrl());
            httpPost.setHeader("Content-Type", "application/json");
            httpPost.setHeader("X-Bce-Api-Key", baiduApiConfig.getApiKey());
            httpPost.setEntity(new StringEntity(requestBody, "UTF-8"));

            try (CloseableHttpClient client = HttpClients.createDefault();
                 CloseableHttpResponse response = client.execute(httpPost)) {
                
                if (response.getStatusLine().getStatusCode() != 200) {
                    String errorBody = EntityUtils.toString(response.getEntity());
                    throw new RuntimeException("API调用失败，状态码：" + response.getStatusLine().getStatusCode() + ", 错误信息：" + errorBody);
                }

                HttpEntity entity = response.getEntity();
                String responseBody = EntityUtils.toString(entity);
                
                JsonNode jsonNode = objectMapper.readTree(responseBody);
                if (!jsonNode.has("choices") || !jsonNode.get("choices").isArray() || jsonNode.get("choices").size() == 0) {
                    throw new RuntimeException("API返回数据格式错误：" + responseBody);
                }

                String content = jsonNode.path("choices").path(0).path("message").path("content").asText("");
                if (content.isEmpty()) {
                    throw new RuntimeException("API返回内容为空");
                }

                List<String> keywords = Arrays.stream(content.split("\n"))
                    .map(String::trim)
                    .filter(s -> !s.isEmpty())
                    .map(s -> s.replaceAll("^[\\d.、\\s-]+", "").trim()) // 移除可能的序号和标点
                    .filter(s -> !s.isEmpty())
                    .distinct() // 去重
                    .toList();

                if (keywords.isEmpty()) {
                    throw new RuntimeException("未能生成有效的关键词");
                }

                return keywords;
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("生成关键词失败: " + e.getMessage());
        }
    }
} 