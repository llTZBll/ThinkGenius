package com.photo.service.impl;

import com.photo.entity.Keyword;
import com.photo.service.BaiduApiService;
import com.photo.service.KeywordService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

@Service
public class KeywordServiceImpl implements KeywordService {

    private final Map<Long, Keyword> keywordMap = new ConcurrentHashMap<>();
    private final AtomicLong idGenerator = new AtomicLong(1);

    @Autowired
    private BaiduApiService baiduApiService;

    @Override
    public Keyword generateKeywords(String prompt) {
        List<String> keywords = baiduApiService.generateKeywords(prompt);
        
        Keyword keyword = new Keyword();
        keyword.setId(idGenerator.getAndIncrement());
        keyword.setPrompt(prompt);
        keyword.setTitle("AI生成的关键词");
        keyword.setType("keyword");
        keyword.setKeywords(keywords);
        
        save(keyword);
        return keyword;
    }

    @Override
    public List<Keyword> list() {
        return new ArrayList<>(keywordMap.values());
    }

    @Override
    public Keyword getById(Long id) {
        return keywordMap.get(id);
    }

    @Override
    public void save(Keyword keyword) {
        if (keyword.getId() == null) {
            keyword.setId(idGenerator.getAndIncrement());
        }
        keywordMap.put(keyword.getId(), keyword);
    }
} 