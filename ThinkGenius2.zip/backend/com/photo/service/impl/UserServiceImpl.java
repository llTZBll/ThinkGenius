package com.photo.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.photo.entity.User;
import com.photo.mapper.UserMapper;
import com.photo.service.UserService;
import com.photo.util.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.regex.Pattern;

@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements UserService {
    
    private static final Pattern EMAIL_PATTERN = Pattern.compile(
        "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$"
    );
    
    @Autowired
    private BCryptPasswordEncoder passwordEncoder;
    
    @Autowired
    private JwtUtil jwtUtil;
    
    @Override
    public String login(String username, String password) {
        if (username == null || username.trim().isEmpty()) {
            throw new RuntimeException("用户名不能为空");
        }
        if (password == null || password.trim().isEmpty()) {
            throw new RuntimeException("密码不能为空");
        }
        
        User user = this.getOne(new LambdaQueryWrapper<User>()
                .eq(User::getUsername, username.trim()));
        
        if (user == null) {
            throw new RuntimeException("用户名或密码错误");
        }
        
        if (!passwordEncoder.matches(password, user.getPassword())) {
            throw new RuntimeException("用户名或密码错误");
        }
        
        return jwtUtil.generateToken(user.getId());
    }
    
    @Override
    @Transactional
    public void register(User user) {
        // 验证用户名
        String username = user.getUsername();
        if (username == null || username.trim().isEmpty()) {
            throw new RuntimeException("用户名不能为空");
        }
        username = username.trim();
        if (username.length() < 3) {
            throw new RuntimeException("用户名长度不能小于3位");
        }
        if (username.length() > 20) {
            throw new RuntimeException("用户名长度不能超过20位");
        }
        
        // 验证邮箱
        String email = user.getEmail();
        if (email == null || email.trim().isEmpty()) {
            throw new RuntimeException("邮箱不能为空");
        }
        email = email.trim();
        if (!EMAIL_PATTERN.matcher(email).matches()) {
            throw new RuntimeException("邮箱格式不正确");
        }
        
        // 验证密码
        String password = user.getPassword();
        if (password == null || password.trim().isEmpty()) {
            throw new RuntimeException("密码不能为空");
        }
        if (password.length() < 6) {
            throw new RuntimeException("密码长度不能小于6位");
        }
        if (password.length() > 20) {
            throw new RuntimeException("密码长度不能超过20位");
        }
        
        // 检查用户名是否已存在
        if (this.count(new LambdaQueryWrapper<User>()
                .eq(User::getUsername, username)) > 0) {
            throw new RuntimeException("用户名已存在");
        }
        
        // 检查邮箱是否已存在
        if (this.count(new LambdaQueryWrapper<User>()
                .eq(User::getEmail, email)) > 0) {
            throw new RuntimeException("邮箱已被使用");
        }
        
        // 设置验证后的值
        user.setUsername(username);
        user.setEmail(email);
        user.setPassword(passwordEncoder.encode(password));
        
        // 保存用户
        this.save(user);
    }
    
    @Override
    public User getCurrentUser() {
        // TODO: 从SecurityContext中获取当前用户ID
        Long userId = 1L; // 临时写死，实际应该从JWT中获取
        return this.getById(userId);
    }
} 