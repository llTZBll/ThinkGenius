<template>
  <div class="bg-gray-50 min-h-screen font-sans">
    <header class="bg-white shadow-sm fixed top-0 left-0 right-0 z-40">
      <div class="container mx-auto px-4 py-3 flex justify-between items-center">
        <button @click="openPanel" class="bg-primary hover:bg-primary/90 text-white px-4 py-2 rounded-lg shadow flex items-center transition-all duration-300">
          <i class="fa fa-magic mr-2"></i>
          <span>AI生成</span>
        </button>
        <h1 class="text-xl font-bold text-neutral">关键词生成器</h1>
        <div v-if="!isLoggedIn" class="flex items-center gap-4">
          <button @click="showLoginModal = true" class="text-gray-600 hover:text-primary transition-colors">
            登录
          </button>
          <button @click="showRegisterModal = true" class="bg-primary hover:bg-primary/90 text-white px-4 py-2 rounded-lg shadow transition-all duration-300">
            注册
          </button>
        </div>
        <div v-else class="flex items-center gap-3">
          <span class="text-gray-600">{{ username }}</span>
          <button @click="logout" class="text-gray-600 hover:text-red-500 transition-colors">
            退出
          </button>
        </div>
      </div>
    </header>

    <main class="container mx-auto px-4 pt-24 pb-16">
      <div class="text-center mb-12">
        <h2 class="text-[clamp(1.5rem,3vw,2.5rem)] font-bold text-neutral mb-4">探索AI生成的关键词</h2>
        <div class="max-w-2xl mx-auto">
          <p class="text-gray-600 mb-6">点击左上角按钮，输入提示词，获取人工智能相关关键词拓展，探索更多可能性</p>
          <div class="relative">
            <input v-model="prompt" type="text" placeholder="输入关键词..." class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-primary focus:border-primary shadow-sm">
            <button @click="generateKeywords" class="absolute right-2 top-1/2 -translate-y-1/2 bg-primary hover:bg-primary/90 text-white px-4 py-2 rounded-lg shadow transition-all duration-300">
              <i class="fa fa-rocket mr-1"></i>生成
            </button>
          </div>
        </div>
      </div>

      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <div v-for="(card, index) in cards" :key="index" class="bg-white rounded-xl shadow-md overflow-hidden transition-all hover:shadow-xl hover:-translate-y-1 duration-300">
          <div :class="card.bgClass" class="h-48 flex items-center justify-center">
            <i :class="card.iconClass"></i>
          </div>
          <div class="p-6">
            <h3 class="text-xl font-semibold mb-2">{{ card.title }}</h3>
            <p class="text-gray-600">{{ card.description }}</p>
          </div>
        </div>
      </div>
    </main>

    <footer class="bg-neutral text-white py-8">
      <div class="container mx-auto px-4">
        <div class="flex flex-col md:flex-row justify-between items-center">
          <div class="mb-4 md:mb-0">
            <h2 class="text-xl font-bold">AI关键词生成器</h2>
            <p class="text-gray-400 mt-1">由AI驱动的关键词拓展工具</p>
          </div>
          <div class="flex space-x-4">
            <a href="#" class="text-gray-400 hover:text-white transition-colors">
              <i class="fa fa-github text-xl"></i>
            </a>
            <a href="#" class="text-gray-400 hover:text-white transition-colors">
              <i class="fa fa-twitter text-xl"></i>
            </a>
            <a href="#" class="text-gray-400 hover:text-white transition-colors">
              <i class="fa fa-linkedin text-xl"></i>
            </a>
          </div>
        </div>
        <div class="border-t border-gray-700 mt-6 pt-6 text-center text-gray-400">
          <p>© 2025 AI关键词生成器. 保留所有权利.</p>
        </div>
      </div>
    </footer>
  </div>
</template>

<script>
export default {
  data() {
    return {
      isLoggedIn: false,
      username: '',
      prompt: '',
      showLoginModal: false,
      showRegisterModal: false,
      cards: [
        {
          title: '创意灵感',
          description: '输入主题，获取相关创意关键词和拓展想法',
          bgClass: 'bg-gradient-to-br from-primary/20 to-secondary/20',
          iconClass: 'fa fa-lightbulb-o text-6xl text-primary/60'
        },
        {
          title: '关键词研究',
          description: '拓展您的搜索词，发现更多相关主题和内容',
          bgClass: 'bg-gradient-to-br from-blue-200 to-purple-200',
          iconClass: 'fa fa-search text-6xl text-blue-500/60'
        },
        {
          title: '内容拓展',
          description: '深入挖掘主题，获取相关文本和内容建议',
          bgClass: 'bg-gradient-to-br from-green-200 to-teal-200',
          iconClass: 'fa fa-puzzle-piece text-6xl text-green-500/60'
        }
      ]
    }
  },
  methods: {
    openPanel() {
      // TODO: 实现打开面板的逻辑
    },
    generateKeywords() {
      // TODO: 实现生成关键词的逻辑
    },
    logout() {
      this.isLoggedIn = false
      this.username = ''
    }
  }
}
</script>

<style>
@tailwind base;
@tailwind components;
@tailwind utilities;

:root {
  --primary: #4F46E5;
  --secondary: #10B981;
  --neutral: #1F2937;
  --light: #F3F4F6;
}
</style> 