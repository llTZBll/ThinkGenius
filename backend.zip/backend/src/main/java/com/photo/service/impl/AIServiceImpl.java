package com.photo.service.impl;

import com.photo.service.AIService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.*;

@Service
public class AIServiceImpl implements AIService {
    
    @Value("${baidu.api.access-token}")
    private String accessToken;
    
    private final RestTemplate restTemplate = new RestTemplate();
    private final String API_URL = "https://aip.baidubce.com/rpc/2.0/ai_custom/v1/wenxinworkshop/chat/completions";
    
    @Override
    public String generateKeywords(String content) {
        String prompt = "请从以下文本中提取5-10个关键词，用逗号分隔：\n" + content;
        return callWenxinAPI(prompt);
    }
    
    @Override
    public String generateQuestions(String content) {
        String prompt = "基于以下文本内容，生成3-5个相关问题：\n" + content;
        return callWenxinAPI(prompt);
    }
    
    @Override
    public String generateSummary(String content) {
        String prompt = "请对以下文本进行摘要，控制在100字以内：\n" + content;
        return callWenxinAPI(prompt);
    }
    
    @Override
    public String analyzeContent(String content) {
        String prompt = "请分析以下文本的内容特点、主题和结构：\n" + content;
        return callWenxinAPI(prompt);
    }
    
    @Override
    public List<String> generateSuggestions(String content) {
        String prompt = "基于以下文本内容，提供3-5个改进或扩展建议：\n" + content;
        String response = callWenxinAPI(prompt);
        
        // 简单的响应解析，将建议分割成列表
        List<String> suggestions = new ArrayList<>();
        if (response != null && !response.isEmpty()) {
            String[] parts = response.split("\\d+\\.");
            for (String part : parts) {
                String trimmed = part.trim();
                if (!trimmed.isEmpty()) {
                    suggestions.add(trimmed);
                }
            }
        }
        
        return suggestions;
    }
    
    @Override
    public String chat(String message) {
        return callWenxinAPI(message);
    }
    
    private String callWenxinAPI(String prompt) {
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            
            Map<String, Object> requestBody = new HashMap<>();
            requestBody.put("messages", Arrays.asList(
                Map.of("role", "user", "content", prompt)
            ));
            
            HttpEntity<Map<String, Object>> request = new HttpEntity<>(requestBody, headers);
            
            String url = API_URL + "?access_token=" + accessToken;
            ResponseEntity<Map> response = restTemplate.postForEntity(url, request, Map.class);
            
            if (response.getStatusCode().is2xxSuccessful() && response.getBody() != null) {
                Map<String, Object> body = response.getBody();
                if (body.containsKey("result")) {
                    return (String) body.get("result");
                }
            }
            
            return "AI服务暂时不可用";
        } catch (Exception e) {
            e.printStackTrace();
            return "AI服务调用失败: " + e.getMessage();
        }
    }
} 